# XMLSec Library: XMLSEC-GCRYPT

## What version of GCrypt?
GCrypt 1.4.0 or later is required.
