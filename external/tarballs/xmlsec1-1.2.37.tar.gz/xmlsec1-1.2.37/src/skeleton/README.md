# XMLSec Library: XMLSEC-SKELETON

## What version of SKELETON?
SKELETON X.Y.Z or later is required.

## Known issues / limitations
TODO